All that you need to do to run both of my programs is this:

Args[0] should be the name of the file
Args[1] should be the sort you wish to perform

DFS = Topological Sort using Depth First Search
SRA = Topological Sort using Source Removal Algorithm

Both sort names are case insensitive. You could even do dFs if you wanted to for depth first search.

Here are example run arguments for both searches:

DFS: "test.txt DFS"
SRA: "test.txt SRA"